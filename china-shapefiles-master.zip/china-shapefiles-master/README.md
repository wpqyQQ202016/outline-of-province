# Standard China Administrative Boundaries

- china\_country.shp
- simplified\_china\_country.shp
- china.shp (with province boundaries)
- china\_nine\_dotted\_line.shp

本项目克隆自github，仅供学习交流使用
原始项目地址https://github.com/dongli/china-shapefiles
